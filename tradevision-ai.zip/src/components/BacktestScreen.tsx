import React, { useState, useEffect } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Play, TrendingUp, ShieldAlert, CheckCircle, RefreshCw, Layers, Calendar, DollarSign, Database, Loader2 } from "lucide-react";
import { BacktestResponse, StrategyType, Trade } from "../types";

export default function BacktestScreen() {
  const [strategy, setStrategy] = useState<StrategyType>("Dual Momentum");
  const [startDate, setStartDate] = useState("2023-01-01");
  const [endDate, setEndDate] = useState("2023-12-31");
  const [initialCash, setInitialCash] = useState("100000");
  
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<BacktestResponse | null>(null);
  const [errorStr, setErrorStr] = useState<string | null>(null);

  // Trigger default backtest simulation on initial load so the screen isn't empty!
  useEffect(() => {
    executeBacktest();
  }, []);

  const executeBacktest = async () => {
    try {
      setLoading(true);
      setErrorStr(null);
      
      const parsedCash = Number(initialCash.replace(/[^0-9.]/g, "")) || 100000;
      
      const response = await fetch("/api/backtest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          strategy,
          tickers: ["SPY", "QQQ", "IWM", "XLK", "XLF", "XLE", "XLV", "GLD", "TLT"],
          start_date: startDate,
          end_date: endDate,
          initial_cash: parsedCash,
        }),
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData?.error || `HTTP error ${response.status}`);
      }

      const data = await response.json() as BacktestResponse;
      setResults(data);
    } catch (err: any) {
      console.error("Backtest execution failure:", err);
      setErrorStr(err.message || "Something went wrong during strategy backtesting");
    } finally {
      setLoading(false);
    }
  };

  const CustomEquityTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#171f33] border border-[#334155] rounded-lg p-3 shadow-xl text-xs font-mono">
          <p className="text-[#94A3B8] mb-1">{payload[0].payload.date}</p>
          <div className="space-y-1">
            <div className="flex justify-between gap-4">
              <span className="text-white">Strategy:</span>
              <span className="text-[#6366F1] font-bold">${payload[0].value.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-[#94A3B8]">Benchmark:</span>
              <span className="text-[#94A3B8] font-bold">${payload[1].value.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const CustomDrawdownTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-[#171f33] border border-[#334155] rounded-lg p-3 shadow-xl text-xs font-mono text-center">
          <p className="text-[#94A3B8] mb-1">{payload[0].payload.date}</p>
          <p className="text-[#F87171] font-bold">Drawdown: {payload[0].value.toFixed(2)}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      
      {/* Simulation Configuration Controller */}
      <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-5 shadow-lg grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-12 gap-4 items-end backdrop-blur-md relative overflow-hidden">
        <div className="col-span-1 sm:col-span-2 xl:col-span-4 w-full">
          <label className="block text-[10px] font-mono uppercase tracking-wide text-[#94A3B8] mb-1.5 select-none">
            Algorithmic Strategy
          </label>
          <select 
            value={strategy}
            onChange={(e) => setStrategy(e.target.value as StrategyType)}
            className="w-full bg-[#0b1326] border border-[#334155] rounded-lg text-sm text-[#e2e8f0] focus:ring-1 focus:ring-[#22D3EE] h-10 px-3 outline-none"
          >
            <option value="Dual Momentum">Dual Momentum (Rank returns &amp; Filter SPY SMA-200)</option>
            <option value="SMA Crossover">SMA Crossover (Golden Cross / Death Cross)</option>
            <option value="Volatility Target">Volatility Target (Inverse-volatility leverage 1.5x)</option>
          </select>
        </div>

        <div className="col-span-1 sm:col-span-1 xl:col-span-2 w-full">
          <label className="block text-[10px] font-mono uppercase tracking-wide text-[#94A3B8] mb-1.5 select-none font-sans">
            Start Date
          </label>
          <div className="relative w-full">
            <Calendar className="w-4 h-4 text-[#94A3B8] absolute left-3 top-3 pointer-events-none" />
            <input 
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full bg-[#0b1326] border border-[#334155] rounded-lg text-sm text-[#e2e8f0] focus:ring-1 focus:ring-[#22D3EE] h-10 pl-9 pr-3 outline-none font-mono"
            />
          </div>
        </div>

        <div className="col-span-1 sm:col-span-1 xl:col-span-2 w-full">
          <label className="block text-[10px] font-mono uppercase tracking-wide text-[#94A3B8] mb-1.5 select-none font-sans">
            End Date
          </label>
          <div className="relative w-full">
            <Calendar className="w-4 h-4 text-[#94A3B8] absolute left-3 top-3 pointer-events-none" />
            <input 
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full bg-[#0b1326] border border-[#334155] rounded-lg text-sm text-[#e2e8f0] focus:ring-1 focus:ring-[#22D3EE] h-10 pl-9 pr-3 outline-none font-mono"
            />
          </div>
        </div>

        <div className="col-span-1 sm:col-span-1 xl:col-span-2 w-full">
          <label className="block text-[10px] font-mono uppercase tracking-wide text-[#94A3B8] mb-1.5 select-none font-sans">
            Initial Capital
          </label>
          <div className="relative w-full">
            <DollarSign className="w-4 h-4 text-[#94A3B8] absolute left-3 top-3 pointer-events-none" />
            <input 
              type="text"
              value={initialCash}
              onChange={(e) => setInitialCash(e.target.value)}
              className="w-full bg-[#0b1326] border border-[#334155] rounded-lg text-sm text-[#e2e8f0] focus:ring-1 focus:ring-[#22D3EE] h-10 pl-8 pr-3 outline-none font-mono text-right"
              placeholder="$100,000"
            />
          </div>
        </div>

        <div className="col-span-1 sm:col-span-1 xl:col-span-2 w-full">
          <button 
            onClick={executeBacktest}
            disabled={loading}
            className="w-full bg-gradient-to-r from-[#6366F1] to-[#22D3EE] text-white h-10 rounded-lg text-xs font-bold font-mono uppercase tracking-wider hover:opacity-95 active:scale-95 transition-all shadow-[0_0_15px_rgba(99,102,241,0.25)] flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Simulating...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-white" />
                <span>RUN BACKTEST</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Error state diagnostics */}
      {errorStr && (
        <div className="bg-[#93000a]/10 border border-[#93000a]/30 rounded-xl p-4 flex items-center gap-3 text-sm text-[#ffbad3]">
          <ShieldAlert className="w-5 h-5 text-[#ffbad3]" />
          <span>Error processing backtest: {errorStr}</span>
        </div>
      )}

      {/* Shimmer loading loader */}
      {loading ? (
        <div className="space-y-6">
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-[#1e293b]/50 border border-[#334155] h-[90px] rounded-xl animate-pulse"></div>
            ))}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            <div className="lg:col-span-8 bg-[#1e293b]/50 border border-[#334155] h-64 rounded-xl animate-pulse"></div>
            <div className="lg:col-span-4 bg-[#1e293b]/50 border border-[#334155] h-64 rounded-xl animate-pulse"></div>
          </div>
        </div>
      ) : results ? (
        <>
          {/* Key Metrics Grid (2x3 or 1x6) */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            
            <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-4 flex flex-col justify-between shadow-md">
              <span className="text-[#94A3B8] text-[9px] font-mono uppercase tracking-wider">Total Return</span>
              <span className={`text-xl font-bold font-mono mt-2 tracking-tight ${results.metrics.total_return_pct >= 0 ? "text-[#10B981]" : "text-[#F87171]"}`}>
                {results.metrics.total_return_pct >= 0 ? "+" : ""}{results.metrics.total_return_pct}%
              </span>
            </div>

            <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-4 flex flex-col justify-between shadow-md">
              <span className="text-[#94A3B8] text-[9px] font-mono uppercase tracking-wider">Ann. Return</span>
              <span className={`text-xl font-bold font-mono mt-2 tracking-tight ${results.metrics.ann_return_pct >= 0 ? "text-[#10B981]" : "text-[#F87171]"}`}>
                {results.metrics.ann_return_pct >= 0 ? "+" : ""}{results.metrics.ann_return_pct}%
              </span>
            </div>

            <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-4 flex flex-col justify-between shadow-md">
              <span className="text-[#94A3B8] text-[9px] font-mono uppercase tracking-wider">Max Drawdown</span>
              <span className="text-xl font-bold font-mono mt-2 tracking-tight text-[#F87171]">
                -{Math.abs(results.metrics.max_drawdown_pct)}%
              </span>
            </div>

            <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-4 flex flex-col justify-between shadow-md">
              <span className="text-[#94A3B8] text-[9px] font-mono uppercase tracking-wider">Calmar Ratio</span>
              <span className="text-xl font-bold font-mono mt-2 tracking-tight text-white">
                {results.metrics.calmar_ratio}
              </span>
            </div>

            <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-4 flex flex-col justify-between shadow-md">
              <span className="text-[#94A3B8] text-[9px] font-mono uppercase tracking-wider">Sharpe Ratio</span>
              <span className="text-xl font-bold font-mono mt-2 tracking-tight text-white">
                {results.metrics.sharpe_ratio}
              </span>
            </div>

            <div className="bg-[#1e293b]/85 border border-[#334155] rounded-xl p-4 flex flex-col justify-between shadow-md">
              <span className="text-[#94A3B8] text-[9px] font-mono uppercase tracking-wider">Win Rate</span>
              <span className="text-xl font-bold font-mono mt-2 tracking-tight text-[#22D3EE]">
                {results.metrics.win_rate_pct}%
              </span>
            </div>

          </div>

          {/* Charts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            
            {/* Equity Curve line chart */}
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-xl p-5 lg:col-span-8 flex flex-col h-[320px] shadow-lg">
              <div className="pb-3 mb-4 border-b border-[#334155] flex justify-between items-center">
                <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">Performance Equity Curve</span>
                <div className="flex gap-4 text-[9px] font-mono text-[#94A3B8]">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-0.5 bg-[#6366F1]"></span>
                    <span>Strategy ({strategy})</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-0.5 border-t border-dashed border-[#94A3B8]"></span>
                    <span>Benchmark (SPY)</span>
                  </div>
                </div>
              </div>

              <div className="flex-1 w-full h-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={results.equity_curve} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="eqFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366F1" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#6366F1" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2d3449" vertical={false} />
                    <XAxis 
                      dataKey="date" 
                      stroke="#464554" 
                      tickLine={false} 
                      axisLine={false}
                      tick={{ fill: "#94A3B8", fontSize: 9, fontFamily: "monospace" }} 
                    />
                    <YAxis 
                      stroke="#464554" 
                      tickLine={false} 
                      axisLine={false}
                      domain={['dataMin - 5000', 'dataMax + 5000']}
                      tickFormatter={(v) => `$${Math.round(v / 1000)}k`}
                      tick={{ fill: "#94A3B8", fontSize: 9, fontFamily: "monospace" }}
                    />
                    <Tooltip content={<CustomEquityTooltip />} />
                    <Area type="monotone" dataKey="strategy" stroke="#6366F1" strokeWidth={2.5} fillOpacity={1} fill="url(#eqFill)" dot={false} activeDot={{ r: 4 }} />
                    <Area type="monotone" dataKey="benchmark" stroke="#464554" strokeWidth={1.5} strokeDasharray="4 4" fill="none" dot={false} activeDot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Drawdown chart */}
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-xl p-5 lg:col-span-4 flex flex-col h-[320px] shadow-lg text-xs leading-none">
              <div className="pb-3 mb-4 border-b border-[#334155]">
                <span className="text-xs font-bold text-white uppercase tracking-wider font-mono">Simulated Drawdown %</span>
              </div>
              <div className="flex-1 w-full h-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={results.drawdown_series} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                    <defs>
                      <linearGradient id="ddFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#F87171" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#F87171" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2d3449" vertical={false} />
                    <XAxis 
                      dataKey="date" 
                      stroke="#464554" 
                      tickLine={false} 
                      axisLine={false}
                      tick={{ fill: "#94A3B8", fontSize: 9, fontFamily: "monospace" }} 
                    />
                    <YAxis 
                      stroke="#464554" 
                      tickLine={false} 
                      axisLine={false}
                      tickFormatter={(v) => `${v}%`}
                      tick={{ fill: "#94A3B8", fontSize: 9, fontFamily: "monospace" }}
                    />
                    <Tooltip content={<CustomDrawdownTooltip />} />
                    <Area type="monotone" dataKey="drawdown" stroke="#F87171" strokeWidth={1.5} fillOpacity={1} fill="url(#ddFill)" dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

          </div>

          {/* Trade History logs table */}
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-xl p-0 overflow-hidden shadow-lg">
            <div className="p-4 border-b border-[#334155] flex justify-between items-center">
              <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Execution Transaction History</h3>
              <span className="bg-[#0b1326] border border-[#334155] text-[#94A3B8] px-2.5 py-1 rounded text-[10px] font-mono">
                {results.trades.length} Simulated trades
              </span>
            </div>
            
            {results.trades.length === 0 ? (
              <div className="p-8 text-center text-[#94A3B8] font-mono text-xs">
                No trades were triggered during this backtest run. Lookback filters were not met.
              </div>
            ) : (
              <div className="w-full overflow-x-auto max-h-72 overflow-y-auto">
                <table className="w-full text-left border-collapse min-w-[700px]">
                  <thead>
                    <tr className="bg-[#0b1326] border-b border-[#334155] text-[10px] font-mono uppercase text-[#94A3B8]">
                      <th className="p-3 select-none">Execution Date</th>
                      <th className="p-3 select-none">Asset</th>
                      <th className="p-3 select-none">Action</th>
                      <th className="p-3 select-none text-right">Qty</th>
                      <th className="p-3 select-none text-right">Execution Price</th>
                      <th className="p-3 select-none text-right">Value</th>
                      <th className="p-3 select-none text-right">P&amp;L</th>
                    </tr>
                  </thead>
                  <tbody className="font-mono text-xs text-white">
                    {results.trades.map((t, idx) => (
                      <tr 
                        key={idx} 
                        className="border-b border-[#334155]/30 hover:bg-[#6366F1]/5 transition-colors"
                      >
                        <td className="p-3 text-[#94A3B8]">{t.date}</td>
                        <td className="p-3 font-bold">{t.ticker}</td>
                        <td className="p-3">
                          <span className={`inline-block text-[9px] font-bold px-2 py-0.5 rounded border border-opacity-30 ${
                            t.side === "buy" 
                              ? "bg-[#10B981]/15 text-[#10B981] border-[#10B981]" 
                              : "bg-[#F87171]/15 text-[#F87171] border-[#F87171]"
                          }`}>
                            {t.side.toUpperCase()}
                          </span>
                        </td>
                        <td className="p-3 text-right">{t.qty.toLocaleString()}</td>
                        <td className="p-3 text-right">${t.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className="p-3 text-right">${t.value.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                        <td className={`p-3 text-all text-right font-medium ${t.pnl > 0 ? "text-[#10B981]" : t.pnl < 0 ? "text-[#F87171]" : "text-[#94A3B8]"}`}>
                          {t.pnl > 0 ? `+$${t.pnl.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : t.pnl < 0 ? `-$${Math.abs(t.pnl).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : "-"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-[#1e293b]/60 border border-[#334155] rounded-xl p-12 text-center text-[#94A3B8] font-mono text-sm max-w-md mx-auto">
          No simulation calculations are currently loaded. Use the configuration panel above to run a backtest.
        </div>
      )}

    </div>
  );
}
